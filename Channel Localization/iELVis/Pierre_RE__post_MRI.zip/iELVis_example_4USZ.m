%% INIT

global globalFsDir;
globalFsDir='C:\Users\megevanp\Documents\GVA_iEEG_freesurfer_subjects\';

myPatient='USZpostopMR';


%% ANATOMICAL PLOTS

% basic parameters
cfgPlot=[];
cfgPlot.title=[];
cfgPlot.backgroundColor=[1 1 1];
cfgPlot.showLabels='n';
cfgPlot.elecShape='marker';
cfgPlot.elecSize=6;
cfgPlot.edgeBlack='y';
cfgPlot.view='lomni';
cfgPlot.pullOut=0;
cfgPlot.opaqueness=1;

% get electrode names and coordinates
cfgPlot.elecNames=readiELVisElecNames(myPatient);
cfgPlot.elecCoord=readiELVisElecCoord(myPatient,'CT');
cfgPlot.elecCoord(:,4)=strcmp('L',cfgPlot.elecNames(:,3));
cfgPlot.elecNames=cfgPlot.elecNames(:,1);

% prepare electrode colors (one per grid/strip/depth)
shaftTmp=cfgPlot.elecNames;
for ctElec=1:numel(shaftTmp)
    shaftTmp{ctElec}(~isletter(shaftTmp{ctElec}))=[];
end
[~,~,shaftIdx]=unique(shaftTmp,'stable');
cfgPlot.elecColors=shaftIdx;
clear shaftTmp shaftIdx;

% colormap options
cfgPlot.elecCmapName='parula(3)';
cfgPlot.elecColorScale='minmax';
cfgPlot.elecCbar='n';

% plot and save
cfgOut=plotPialSurf(myPatient,cfgPlot);
%print('USZ_allElecs.tif','-dtiff','-r300');

% add Desikan-Killiany parcellation overlay
cfgPlot.overlayParcellation='DK';
cfgOut=plotPialSurf(myPatient,cfgPlot);
%print('USZ_allElecs_DK.tif','-dtiff','-r300');


%% PLOT SOME STATISTIC AT EACH ELECTRODE AS A COLOR CODE

% let's say the variable myStat is what you want to plot
myStat=randn(80,1); % 80 is the total number of electrodes for USZ

% basic parameters
cfgPlot=[];
cfgPlot.title=[];
cfgPlot.backgroundColor=[1 1 1];
cfgPlot.showLabels='n';
cfgPlot.elecShape='marker';
cfgPlot.elecSize=8;
cfgPlot.edgeBlack='y';
cfgPlot.view='l';
cfgPlot.pullOut=0;

% get electrode names and coordinates
cfgPlot.elecNames=readiELVisElecNames(myPatient);
cfgPlot.elecCoord=readiELVisElecCoord(myPatient,'CT');
cfgPlot.elecCoord(:,4)=strcmp('L',cfgPlot.elecNames(:,3));
cfgPlot.elecNames=cfgPlot.elecNames(:,1);

% prepare to pass the data to plotPialSurf
cfgPlot.elecColors=myStat;
cfgPlot.elecCmapName='autumn';
cfgPlot.elecColorScale='minmax';
cfgPlot.elecCbar='y';
cfgPlot.elecUnits='z [a.u.]';

% plot
cfgOut=plotPialSurf(myPatient,cfgPlot);

